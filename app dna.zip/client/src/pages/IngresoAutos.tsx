import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Plus, Car, Check } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

export default function IngresoAutos() {
  const [cliente, setCliente] = useState("");
  const [telefono, setTelefono] = useState("");
  const [placa, setPlaca] = useState("");
  const [marca, setMarca] = useState("");
  const [modelo, setModelo] = useState("");
  const [anio, setAnio] = useState("");
  const [color, setColor] = useState("");
  const [motor, setMotor] = useState("");
  const [cilindraje, setCilindraje] = useState("");
  const [kilometraje, setKilometraje] = useState("");
  const [servicio, setServicio] = useState("");
  const [observaciones, setObservaciones] = useState("");
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  const createMutation = trpc.autos.create.useMutation();

  const guardarIngreso = async () => {
    if (!cliente.trim()) {
      toast.error("Ingresa el nombre del cliente");
      return;
    }
    if (!placa.trim()) {
      toast.error("Ingresa la placa del vehículo");
      return;
    }

    setSaving(true);
    try {
      await createMutation.mutateAsync({
        cliente: cliente.trim(),
        telefono: telefono.trim() || undefined,
        placa: placa.trim(),
        marca: marca.trim() || "N/A",
        modelo: modelo.trim() || "N/A",
        anio: anio.trim() || undefined,
        color: color.trim() || undefined,
        motor: motor.trim() || undefined,
        cilindraje: cilindraje.trim() || undefined,
        kilometraje: kilometraje.trim() || undefined,
        servicioRequerido: servicio.trim() || "Por definir",
        diagnostico: observaciones.trim() || undefined,
        fechaIngreso: new Date().toISOString().split("T")[0],
      });
      setSuccess(true);
      toast.success("Vehículo registrado exitosamente");
      // Reset form after short delay
      setTimeout(() => {
        setCliente("");
        setTelefono("");
        setPlaca("");
        setMarca("");
        setModelo("");
        setAnio("");
        setColor("");
        setMotor("");
        setCilindraje("");
        setKilometraje("");
        setServicio("");
        setObservaciones("");
        setSuccess(false);
      }, 2000);
    } catch {
      toast.error("Error al registrar el vehículo");
    } finally {
      setSaving(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 rounded-lg bg-orange-500/10">
            <Car className="w-5 h-5 text-orange-600" />
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-foreground" style={{ fontFamily: "'Oswald', sans-serif" }}>
            Ingreso de Autos
          </h1>
        </div>

        {/* Client Info */}
        <Card className="p-4 sm:p-5 mb-4">
          <h3 className="text-sm font-bold text-foreground mb-3 uppercase tracking-wide">
            Datos del Cliente
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Nombre del Cliente *</Label>
              <Input value={cliente} onChange={(e) => setCliente(e.target.value)} placeholder="Nombre completo" className="h-9 text-sm" />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Teléfono</Label>
              <Input value={telefono} onChange={(e) => setTelefono(e.target.value)} placeholder="5555-1234" className="h-9 text-sm" />
            </div>
          </div>
        </Card>

        {/* Vehicle Info */}
        <Card className="p-4 sm:p-5 mb-4">
          <h3 className="text-sm font-bold text-foreground mb-3 uppercase tracking-wide">
            Datos del Vehículo
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Placa *</Label>
              <Input value={placa} onChange={(e) => setPlaca(e.target.value)} placeholder="P-123ABC" className="h-9 text-sm" />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Marca</Label>
              <Input value={marca} onChange={(e) => setMarca(e.target.value)} placeholder="Toyota" className="h-9 text-sm" />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Modelo</Label>
              <Input value={modelo} onChange={(e) => setModelo(e.target.value)} placeholder="Corolla" className="h-9 text-sm" />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Año</Label>
              <Input value={anio} onChange={(e) => setAnio(e.target.value)} placeholder="2024" className="h-9 text-sm" />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Color</Label>
              <Input value={color} onChange={(e) => setColor(e.target.value)} placeholder="Negro" className="h-9 text-sm" />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Motor</Label>
              <Input value={motor} onChange={(e) => setMotor(e.target.value)} placeholder="1.8L" className="h-9 text-sm" />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Cilindraje</Label>
              <Input value={cilindraje} onChange={(e) => setCilindraje(e.target.value)} placeholder="1800cc" className="h-9 text-sm" />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Kilometraje</Label>
              <Input value={kilometraje} onChange={(e) => setKilometraje(e.target.value)} placeholder="50,000 km" className="h-9 text-sm" />
            </div>
          </div>
        </Card>

        {/* Service Info */}
        <Card className="p-4 sm:p-5 mb-4">
          <h3 className="text-sm font-bold text-foreground mb-3 uppercase tracking-wide">
            Servicio Requerido
          </h3>
          <div className="space-y-3">
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Servicio / Trabajo a realizar</Label>
              <Input value={servicio} onChange={(e) => setServicio(e.target.value)} placeholder="Ej. Servicio básico, cambio de frenos..." className="h-9 text-sm" />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Observaciones</Label>
              <textarea
                value={observaciones}
                onChange={(e) => setObservaciones(e.target.value)}
                placeholder="Notas adicionales sobre el estado del vehículo, daños existentes, etc."
                className="w-full h-20 rounded-md border border-input bg-background px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
          </div>
        </Card>

        {/* Save Button */}
        <Button
          onClick={guardarIngreso}
          disabled={saving || success}
          className={`w-full h-12 text-base font-semibold active:scale-[0.97] transition-all ${
            success ? "bg-green-600 hover:bg-green-600" : "bg-primary hover:bg-primary/90"
          } text-primary-foreground`}
        >
          {success ? (
            <>
              <Check className="w-5 h-5 mr-2" />
              Registrado
            </>
          ) : saving ? (
            "Guardando..."
          ) : (
            <>
              <Plus className="w-5 h-5 mr-2" />
              Registrar Ingreso
            </>
          )}
        </Button>
      </div>
    </DashboardLayout>
  );
}

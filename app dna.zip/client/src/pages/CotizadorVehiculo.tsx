import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Trash2, Plus, Download } from "lucide-react";
import { toast } from "sonner";
import { formatCurrency } from "@/lib/formatCurrency";
import { generarPDFCotizacion } from "@/lib/pdfGenerator";
import { trpc } from "@/lib/trpc";

interface Item {
  id: number;
  cantidad: number;
  concepto: string;
  precio: number;
  total: number;
}

export default function CotizadorVehiculo() {
  const [cliente, setCliente] = useState("");
  const [fecha, setFecha] = useState(() => new Date().toISOString().split("T")[0]);
  const [placa, setPlaca] = useState("");
  const [marca, setMarca] = useState("");
  const [modelo, setModelo] = useState("");
  const [anio, setAnio] = useState("");
  const [color, setColor] = useState("");
  const [motor, setMotor] = useState("");
  const [cilindraje, setCilindraje] = useState("");
  const [servicio, setServicio] = useState("");
  const [cantidad, setCantidad] = useState("");
  const [concepto, setConcepto] = useState("");
  const [precio, setPrecio] = useState("");
  const [items, setItems] = useState<Item[]>([]);
  const [saving, setSaving] = useState(false);

  const createMutation = trpc.cotizaciones.create.useMutation();

  const agregarFila = () => {
    const cant = parseInt(cantidad) || 1;
    const prec = parseFloat(precio) || 0;

    if (!concepto.trim()) {
      toast.error("Ingresa un concepto o descripción");
      return;
    }
    if (prec <= 0) {
      toast.error("Ingresa un precio válido");
      return;
    }

    const newItem: Item = {
      id: Date.now(),
      cantidad: cant,
      concepto: concepto.trim(),
      precio: prec,
      total: cant * prec,
    };

    setItems([...items, newItem]);
    setCantidad("");
    setConcepto("");
    setPrecio("");
    toast.success("Concepto agregado");
  };

  const eliminarFila = (id: number) => {
    setItems(items.filter((item) => item.id !== id));
    toast("Concepto eliminado");
  };

  const total = items.reduce((sum, item) => sum + item.total, 0);

  const descargarPDF = () => {
    if (items.length === 0) {
      toast.error("Agrega al menos un concepto");
      return;
    }
    if (!cliente.trim()) {
      toast.error("Ingresa el nombre del cliente");
      return;
    }

    generarPDFCotizacion({
      tipo: "vehiculo",
      cliente: cliente.trim(),
      fecha,
      placa: placa.trim() || undefined,
      marca: marca.trim() || undefined,
      modelo: modelo.trim() || undefined,
      anio: anio.trim() || undefined,
      color: color.trim() || undefined,
      motor: motor.trim() || undefined,
      cilindraje: cilindraje.trim() || undefined,
      servicio: servicio.trim() || undefined,
      total: total.toString(),
      items: items.map(item => ({
        cantidad: item.cantidad,
        concepto: item.concepto,
        precioUnitario: item.precio.toString(),
        total: item.total.toString(),
      })),
    });

    toast.success("PDF descargado");
  };

  const guardarCotizacion = async () => {
    if (items.length === 0) {
      toast.error("Agrega al menos un concepto");
      return;
    }
    if (!cliente.trim()) {
      toast.error("Ingresa el nombre del cliente");
      return;
    }

    setSaving(true);
    try {
      await createMutation.mutateAsync({
        tipo: "vehiculo",
        cliente: cliente.trim(),
        fecha,
        placa: placa.trim() || undefined,
        marca: marca.trim() || undefined,
        modelo: modelo.trim() || undefined,
        anio: anio.trim() || undefined,
        color: color.trim() || undefined,
        motor: motor.trim() || undefined,
        cilindraje: cilindraje.trim() || undefined,
        servicio: servicio.trim() || undefined,
        total: total.toString(),
        items: items.map(item => ({
          cantidad: item.cantidad,
          concepto: item.concepto,
          precioUnitario: item.precio.toString(),
          total: item.total.toString(),
        })),
      });
      toast.success("Cotización guardada en el historial");
    } catch {
      toast.error("Error al guardar la cotización");
    } finally {
      setSaving(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="max-w-3xl mx-auto">
        <h1 className="text-xl sm:text-2xl font-bold text-foreground mb-6" style={{ fontFamily: "'Oswald', sans-serif" }}>
          Cotizador con Datos del Vehículo
        </h1>

        {/* Client & Vehicle Info */}
        <Card className="p-4 sm:p-5 mb-4">
          <h3 className="text-sm font-bold text-foreground mb-3 uppercase tracking-wide">
            Datos del Cliente y Vehículo
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Cliente *</Label>
              <Input value={cliente} onChange={(e) => setCliente(e.target.value)} placeholder="Nombre del cliente" className="h-9 text-sm" />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Fecha</Label>
              <Input type="date" value={fecha} onChange={(e) => setFecha(e.target.value)} className="h-9 text-sm" />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Placa</Label>
              <Input value={placa} onChange={(e) => setPlaca(e.target.value)} placeholder="P-123ABC" className="h-9 text-sm" />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Marca</Label>
              <Input value={marca} onChange={(e) => setMarca(e.target.value)} placeholder="Toyota, Honda..." className="h-9 text-sm" />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Modelo</Label>
              <Input value={modelo} onChange={(e) => setModelo(e.target.value)} placeholder="Corolla, Civic..." className="h-9 text-sm" />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Año</Label>
              <Input value={anio} onChange={(e) => setAnio(e.target.value)} placeholder="2024" className="h-9 text-sm" />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Color</Label>
              <Input value={color} onChange={(e) => setColor(e.target.value)} placeholder="Negro, Blanco..." className="h-9 text-sm" />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Motor</Label>
              <Input value={motor} onChange={(e) => setMotor(e.target.value)} placeholder="1.8L, 2.0T..." className="h-9 text-sm" />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Cilindraje</Label>
              <Input value={cilindraje} onChange={(e) => setCilindraje(e.target.value)} placeholder="1800cc" className="h-9 text-sm" />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Servicio Requerido</Label>
              <Input value={servicio} onChange={(e) => setServicio(e.target.value)} placeholder="Servicio básico, cambio de luces..." className="h-9 text-sm" />
            </div>
          </div>
        </Card>

        {/* Add Items */}
        <Card className="p-4 sm:p-5 mb-4 bg-muted/30">
          <h3 className="text-sm font-bold text-foreground mb-3 uppercase tracking-wide">
            Agregar Concepto
          </h3>
          <div className="grid grid-cols-[60px_1fr_100px] sm:grid-cols-[80px_1fr_120px] gap-2 sm:gap-3 mb-3">
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Cant.</Label>
              <Input
                type="number"
                value={cantidad}
                onChange={(e) => setCantidad(e.target.value)}
                placeholder="1"
                min="1"
                className="h-9 text-sm"
              />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Concepto</Label>
              <Input
                value={concepto}
                onChange={(e) => setConcepto(e.target.value)}
                placeholder="Ej. Kit de luces LED"
                className="h-9 text-sm"
                onKeyDown={(e) => e.key === "Enter" && agregarFila()}
              />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Precio (Q)</Label>
              <Input
                type="number"
                value={precio}
                onChange={(e) => setPrecio(e.target.value)}
                placeholder="0"
                step="0.01"
                className="h-9 text-sm"
                onKeyDown={(e) => e.key === "Enter" && agregarFila()}
              />
            </div>
          </div>
          <Button
            onClick={agregarFila}
            size="sm"
            className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            <Plus className="w-4 h-4 mr-1" />
            Agregar
          </Button>
        </Card>

        {/* Items Table */}
        {items.length > 0 && (
          <Card className="mb-4 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-foreground text-background">
                    <th className="py-2.5 px-3 text-left text-xs font-semibold w-[12%] text-center">Cant.</th>
                    <th className="py-2.5 px-3 text-left text-xs font-semibold">Concepto</th>
                    <th className="py-2.5 px-3 text-right text-xs font-semibold w-[22%] whitespace-nowrap">Precio</th>
                    <th className="py-2.5 px-3 text-center text-xs font-semibold w-[10%]"></th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((item) => (
                    <tr key={item.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                      <td className="py-2.5 px-3 text-center">{item.cantidad}</td>
                      <td className="py-2.5 px-3">{item.concepto}</td>
                      <td className="py-2.5 px-3 text-right whitespace-nowrap font-mono text-xs">
                        Q. {formatCurrency(item.precio)}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <button
                          onClick={() => eliminarFila(item.id)}
                          className="text-destructive hover:text-destructive/80 transition-colors p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Total */}
            <div className="flex justify-end items-center gap-4 p-3 sm:p-4 bg-muted/20 border-t border-border">
              <span className="font-bold text-sm text-foreground">TOTAL:</span>
              <span className="font-bold text-base sm:text-lg font-mono text-foreground">
                Q. {formatCurrency(total)}
              </span>
            </div>
          </Card>
        )}

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
          <Button
            onClick={descargarPDF}
            className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground h-11 active:scale-[0.97] transition-transform"
          >
            <Download className="w-4 h-4 mr-2" />
            Descargar PDF
          </Button>
          <Button
            onClick={guardarCotizacion}
            variant="outline"
            disabled={saving}
            className="flex-1 h-11 active:scale-[0.97] transition-transform"
          >
            {saving ? "Guardando..." : "Guardar en Historial"}
          </Button>
        </div>
      </div>
    </DashboardLayout>
  );
}

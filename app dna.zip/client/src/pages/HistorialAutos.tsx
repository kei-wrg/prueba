import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Car, Trash2, Search, Clock, CheckCircle, Wrench, Truck } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

interface IngresoAuto {
  id: number;
  cliente: string;
  telefono: string | null;
  placa: string;
  marca: string;
  modelo: string;
  anio: string | null;
  color: string | null;
  motor: string | null;
  cilindraje: string | null;
  kilometraje: string | null;
  servicioRequerido: string;
  diagnostico: string | null;
  estado: string;
  fechaIngreso: Date;
  fechaEntrega: Date | null;
  notas: string | null;
  createdAt: Date;
}

const estadoConfig: Record<string, { label: string; icon: React.ReactNode; color: string }> = {
  pendiente: { label: "Pendiente", icon: <Clock className="w-3 h-3" />, color: "text-yellow-600 bg-yellow-50" },
  en_proceso: { label: "En Proceso", icon: <Wrench className="w-3 h-3" />, color: "text-blue-600 bg-blue-50" },
  completado: { label: "Completado", icon: <CheckCircle className="w-3 h-3" />, color: "text-green-600 bg-green-50" },
  entregado: { label: "Entregado", icon: <Truck className="w-3 h-3" />, color: "text-purple-600 bg-purple-50" },
};

export default function HistorialAutos() {
  const [busqueda, setBusqueda] = useState("");
  const { data: autos, refetch } = trpc.autos.list.useQuery();
  const deleteMutation = trpc.autos.delete.useMutation();
  const updateMutation = trpc.autos.update.useMutation();

  const autosFiltrados = (autos as IngresoAuto[] | undefined)?.filter((a) => {
    if (!busqueda.trim()) return true;
    const term = busqueda.toLowerCase();
    return (
      a.cliente.toLowerCase().includes(term) ||
      a.placa.toLowerCase().includes(term) ||
      a.marca.toLowerCase().includes(term) ||
      a.modelo.toLowerCase().includes(term)
    );
  }) || [];

  const eliminar = async (id: number) => {
    try {
      await deleteMutation.mutateAsync({ id });
      refetch();
      toast("Registro eliminado");
    } catch {
      toast.error("Error al eliminar");
    }
  };

  const cambiarEstado = async (id: number, nuevoEstado: string) => {
    try {
      await updateMutation.mutateAsync({ id, estado: nuevoEstado as any });
      refetch();
      toast.success("Estado actualizado");
    } catch {
      toast.error("Error al actualizar");
    }
  };

  return (
    <DashboardLayout>
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 rounded-lg bg-orange-500/10">
            <Car className="w-5 h-5 text-orange-600" />
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-foreground" style={{ fontFamily: "'Oswald', sans-serif" }}>
            Historial de Autos
          </h1>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            placeholder="Buscar por cliente, placa, marca o modelo..."
            className="pl-9 h-10 text-sm"
          />
        </div>

        {/* List */}
        {autosFiltrados.length > 0 ? (
          <div className="space-y-2">
            {autosFiltrados.map((auto) => {
              const estado = estadoConfig[auto.estado] || estadoConfig.pendiente;
              return (
                <Card key={auto.id} className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-semibold text-sm truncate">{auto.cliente}</p>
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold ${estado.color}`}>
                          {estado.icon}
                          {estado.label}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {auto.marca} {auto.modelo} {auto.anio && `(${auto.anio})`} | Placa: {auto.placa}
                      </p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        Servicio: {auto.servicioRequerido}
                      </p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">
                        Ingreso: {new Date(auto.fechaIngreso).toLocaleDateString()}
                        {auto.telefono && ` | Tel: ${auto.telefono}`}
                      </p>
                    </div>
                    <div className="flex flex-col items-end gap-1 shrink-0">
                      <select
                        value={auto.estado}
                        onChange={(e) => cambiarEstado(auto.id, e.target.value)}
                        className="text-[10px] h-6 rounded border border-input bg-background px-1"
                      >
                        <option value="pendiente">Pendiente</option>
                        <option value="en_proceso">En Proceso</option>
                        <option value="completado">Completado</option>
                        <option value="entregado">Entregado</option>
                      </select>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => eliminar(auto.id)}
                        className="h-7 w-7 p-0 text-destructive hover:text-destructive/80"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card className="p-8 text-center">
            <Car className="w-8 h-8 text-muted-foreground/50 mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">
              {busqueda ? "No se encontraron autos con ese criterio" : "No hay autos registrados aún"}
            </p>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}

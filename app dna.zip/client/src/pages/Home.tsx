import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { FileText, Car, Wallet, Wrench } from "lucide-react";
import { useLocation } from "wouter";

const LOGO_URL = "/manus-storage/image-removebg-preview_fb04c91b.png";

export default function Home() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const modules = [
    {
      icon: FileText,
      title: "Cotizador Simple",
      description: "Cotizaciones rápidas sin datos del vehículo",
      path: "/cotizador-simple",
      color: "bg-emerald-500/10 text-emerald-600",
    },
    {
      icon: Car,
      title: "Cotizador Vehículo",
      description: "Cotizaciones con datos completos del auto",
      path: "/cotizador-vehiculo",
      color: "bg-blue-500/10 text-blue-600",
    },
    {
      icon: Wrench,
      title: "Ingreso de Autos",
      description: "Registrar vehículos que ingresan al taller",
      path: "/ingreso-autos",
      color: "bg-orange-500/10 text-orange-600",
    },
    {
      icon: Wallet,
      title: "Finanzas",
      description: "Control de ingresos y egresos por mes",
      path: "/finanzas",
      color: "bg-purple-500/10 text-purple-600",
    },
  ];

  return (
    <DashboardLayout>
      <div className="max-w-5xl mx-auto">
        {/* Welcome header */}
        <div className="flex items-center gap-4 mb-8">
          <img src={LOGO_URL} alt="Taller DNA" className="w-14 h-14 sm:w-16 sm:h-16 object-contain" />
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-foreground" style={{ fontFamily: "'Oswald', sans-serif" }}>
              Bienvenido{user?.name ? `, ${user.name}` : ""}
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Sistema de gestión - Taller DNA
            </p>
          </div>
        </div>

        {/* Quick access modules */}
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">
          Acceso Rápido
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          {modules.map((mod) => (
            <Card
              key={mod.path}
              className="p-4 sm:p-5 cursor-pointer hover:shadow-md transition-all active:scale-[0.98] border border-border/50"
              onClick={() => setLocation(mod.path)}
            >
              <div className="flex items-start gap-3">
                <div className={`p-2.5 rounded-lg ${mod.color}`}>
                  <mod.icon className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-sm sm:text-base text-foreground">
                    {mod.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-muted-foreground mt-0.5">
                    {mod.description}
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}

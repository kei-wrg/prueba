import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ClipboardList, Trash2, Download, Search, Car, FileText } from "lucide-react";
import { toast } from "sonner";
import { formatCurrency } from "@/lib/formatCurrency";
import { generateSimplePDF, generateVehiclePDF } from "@/lib/pdfGenerator";
import { trpc } from "@/lib/trpc";

interface CotizacionItem {
  id: number;
  cantidad: number;
  concepto: string;
  precioUnitario: string;
  total: string;
}

interface Cotizacion {
  id: number;
  tipo: string;
  cliente: string;
  fecha: Date;
  placa: string | null;
  marca: string | null;
  modelo: string | null;
  anio: string | null;
  color: string | null;
  motor: string | null;
  cilindraje: string | null;
  servicio: string | null;
  total: string;
  notas: string | null;
  items?: CotizacionItem[];
  createdAt: Date;
}

export default function Historial() {
  const [busqueda, setBusqueda] = useState("");
  const { data: cotizaciones, refetch } = trpc.cotizaciones.list.useQuery();
  const deleteMutation = trpc.cotizaciones.delete.useMutation();

  const cotizacionesFiltradas = (cotizaciones as Cotizacion[] | undefined)?.filter((c) => {
    if (!busqueda.trim()) return true;
    const term = busqueda.toLowerCase();
    return (
      c.cliente.toLowerCase().includes(term) ||
      c.placa?.toLowerCase().includes(term) ||
      c.marca?.toLowerCase().includes(term) ||
      c.modelo?.toLowerCase().includes(term)
    );
  }) || [];

  const eliminar = async (id: number) => {
    try {
      await deleteMutation.mutateAsync({ id });
      refetch();
      toast("Cotización eliminada");
    } catch {
      toast.error("Error al eliminar");
    }
  };

  const descargarPDF = (cot: Cotizacion) => {
    if (!cot.items || cot.items.length === 0) {
      toast.error("Esta cotización no tiene items para generar PDF");
      return;
    }

    const items = cot.items.map((item) => ({
      cantidad: item.cantidad,
      concepto: item.concepto,
      precio: parseFloat(item.precioUnitario),
      total: parseFloat(item.total),
    }));

    if (cot.tipo === "vehiculo") {
      generateVehiclePDF({
        cliente: cot.cliente,
        fecha: new Date(cot.fecha).toISOString().split("T")[0],
        placa: cot.placa || "",
        marca: cot.marca || "",
        modelo: cot.modelo || "",
        anio: cot.anio || "",
        color: cot.color || "",
        motor: cot.motor || "",
        cilindraje: cot.cilindraje || "",
        items,
        total: parseFloat(cot.total),
      });
    } else {
      generateSimplePDF({
        cliente: cot.cliente,
        fecha: new Date(cot.fecha).toISOString().split("T")[0],
        items,
        total: parseFloat(cot.total),
      });
    }
    toast.success("PDF descargado");
  };

  return (
    <DashboardLayout>
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 rounded-lg bg-blue-500/10">
            <ClipboardList className="w-5 h-5 text-blue-600" />
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-foreground" style={{ fontFamily: "'Oswald', sans-serif" }}>
            Historial de Cotizaciones
          </h1>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            placeholder="Buscar por cliente, placa, marca o modelo..."
            className="pl-9 h-10 text-sm"
          />
        </div>

        {/* List */}
        {cotizacionesFiltradas.length > 0 ? (
          <div className="space-y-2">
            {cotizacionesFiltradas.map((cot) => (
              <Card key={cot.id} className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <div className={`p-2 rounded-lg shrink-0 ${cot.tipo === "vehiculo" ? "bg-orange-500/10" : "bg-primary/10"}`}>
                      {cot.tipo === "vehiculo" ? (
                        <Car className="w-4 h-4 text-orange-600" />
                      ) : (
                        <FileText className="w-4 h-4 text-primary" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <p className="font-semibold text-sm truncate">{cot.cliente}</p>
                      <p className="text-[10px] text-muted-foreground">
                        {new Date(cot.fecha).toLocaleDateString()} 
                        {cot.tipo === "vehiculo" && cot.marca && ` | ${cot.marca} ${cot.modelo || ""}`}
                        {cot.placa && ` | ${cot.placa}`}
                      </p>
                      <p className="text-xs font-bold font-mono text-primary mt-1">
                        Q. {formatCurrency(parseFloat(cot.total))}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => descargarPDF(cot)}
                      className="h-8 w-8 p-0 text-primary hover:text-primary/80"
                    >
                      <Download className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => eliminar(cot.id)}
                      className="h-8 w-8 p-0 text-destructive hover:text-destructive/80"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="p-8 text-center">
            <ClipboardList className="w-8 h-8 text-muted-foreground/50 mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">
              {busqueda ? "No se encontraron cotizaciones con ese criterio" : "No hay cotizaciones guardadas aún"}
            </p>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}

import { useState, useMemo } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Plus, Trash2, Wallet, TrendingUp, TrendingDown, FileSpreadsheet, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { formatCurrency } from "@/lib/formatCurrency";
import { trpc } from "@/lib/trpc";

const MESES = [
  "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
  "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
];

interface Movimiento {
  id: number;
  hojaId: number;
  tipo: string;
  descripcion: string;
  monto: string;
  fecha: Date;
  categoria: string | null;
  notas: string | null;
  createdAt: Date;
}

interface Hoja {
  id: number;
  nombre: string;
  mes: number;
  anio: number;
  totalIngresos: string;
  totalEgresos: string;
  balance: string;
}

export default function Finanzas() {
  const now = new Date();
  const [hojaActiva, setHojaActiva] = useState<number | null>(null);
  const [descripcion, setDescripcion] = useState("");
  const [monto, setMonto] = useState("");
  const [tipoNuevo, setTipoNuevo] = useState<"ingreso" | "egreso">("ingreso");
  const [saving, setSaving] = useState(false);
  const [creandoHoja, setCreandoHoja] = useState(false);
  const [nuevoMes, setNuevoMes] = useState(now.getMonth() + 1);
  const [nuevoAnio, setNuevoAnio] = useState(now.getFullYear());

  const { data: hojas, refetch: refetchHojas } = trpc.finanzas.listHojas.useQuery();
  const { data: hojaData, refetch: refetchHoja } = trpc.finanzas.getHoja.useQuery(
    { id: hojaActiva! },
    { enabled: !!hojaActiva }
  );

  const createHojaMutation = trpc.finanzas.createHoja.useMutation();
  const deleteHojaMutation = trpc.finanzas.deleteHoja.useMutation();
  const createMovMutation = trpc.finanzas.createMovimiento.useMutation();
  const deleteMovMutation = trpc.finanzas.deleteMovimiento.useMutation();

  const movimientos = (hojaData as { movimientos?: Movimiento[] })?.movimientos || [];
  const hoja = hojaData as Hoja | undefined;

  const { ingresos, egresos, balance } = useMemo(() => {
    if (!movimientos.length) return { ingresos: 0, egresos: 0, balance: 0 };
    const ing = movimientos.filter((m: Movimiento) => m.tipo === "ingreso").reduce((sum: number, m: Movimiento) => sum + parseFloat(m.monto), 0);
    const egr = movimientos.filter((m: Movimiento) => m.tipo === "egreso").reduce((sum: number, m: Movimiento) => sum + parseFloat(m.monto), 0);
    return { ingresos: ing, egresos: egr, balance: ing - egr };
  }, [movimientos]);

  const crearHoja = async () => {
    try {
      const nombre = `${MESES[nuevoMes - 1]} ${nuevoAnio}`;
      const result = await createHojaMutation.mutateAsync({
        nombre,
        mes: nuevoMes,
        anio: nuevoAnio,
      });
      refetchHojas();
      setHojaActiva(result.id);
      setCreandoHoja(false);
      toast.success(`Hoja "${nombre}" creada`);
    } catch {
      toast.error("Error al crear la hoja");
    }
  };

  const eliminarHoja = async (id: number) => {
    try {
      await deleteHojaMutation.mutateAsync({ id });
      refetchHojas();
      if (hojaActiva === id) setHojaActiva(null);
      toast("Hoja eliminada");
    } catch {
      toast.error("Error al eliminar");
    }
  };

  const agregarMovimiento = async () => {
    if (!hojaActiva) return;
    const montoNum = parseFloat(monto);
    if (!descripcion.trim()) {
      toast.error("Ingresa una descripción");
      return;
    }
    if (!montoNum || montoNum <= 0) {
      toast.error("Ingresa un monto válido");
      return;
    }

    setSaving(true);
    try {
      await createMovMutation.mutateAsync({
        hojaId: hojaActiva,
        tipo: tipoNuevo,
        descripcion: descripcion.trim(),
        monto: montoNum.toString(),
        fecha: new Date().toISOString().split("T")[0],
      });
      setDescripcion("");
      setMonto("");
      refetchHoja();
      toast.success(`${tipoNuevo === "ingreso" ? "Ingreso" : "Egreso"} registrado`);
    } catch {
      toast.error("Error al registrar movimiento");
    } finally {
      setSaving(false);
    }
  };

  const eliminarMovimiento = async (id: number) => {
    try {
      await deleteMovMutation.mutateAsync({ id });
      refetchHoja();
      toast("Movimiento eliminado");
    } catch {
      toast.error("Error al eliminar");
    }
  };

  // View: List of sheets (like Excel tabs)
  if (!hojaActiva) {
    return (
      <DashboardLayout>
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-lg bg-purple-500/10">
              <Wallet className="w-5 h-5 text-purple-600" />
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-foreground" style={{ fontFamily: "'Oswald', sans-serif" }}>
              Control Financiero
            </h1>
          </div>

          {/* Create new sheet */}
          {creandoHoja ? (
            <Card className="p-4 mb-4 bg-muted/30">
              <h3 className="text-sm font-bold mb-3">Nueva Hoja Mensual</h3>
              <div className="grid grid-cols-2 gap-3 mb-3">
                <div>
                  <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Mes</Label>
                  <select
                    value={nuevoMes}
                    onChange={(e) => setNuevoMes(parseInt(e.target.value))}
                    className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm"
                  >
                    {MESES.map((m, i) => (
                      <option key={i} value={i + 1}>{m}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Año</Label>
                  <Input
                    type="number"
                    value={nuevoAnio}
                    onChange={(e) => setNuevoAnio(parseInt(e.target.value))}
                    className="h-9 text-sm"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Button size="sm" onClick={crearHoja} className="bg-primary text-primary-foreground">
                  Crear
                </Button>
                <Button size="sm" variant="outline" onClick={() => setCreandoHoja(false)}>
                  Cancelar
                </Button>
              </div>
            </Card>
          ) : (
            <Button
              onClick={() => setCreandoHoja(true)}
              className="w-full mb-4 h-11 bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              <Plus className="w-4 h-4 mr-2" />
              Nueva Hoja Mensual
            </Button>
          )}

          {/* List of sheets */}
          {hojas && hojas.length > 0 ? (
            <div className="space-y-2">
              {(hojas as Hoja[]).map((h) => {
                const bal = parseFloat(h.balance);
                return (
                  <Card
                    key={h.id}
                    className="p-4 cursor-pointer hover:bg-muted/30 transition-colors active:scale-[0.99]"
                    onClick={() => setHojaActiva(h.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <FileSpreadsheet className="w-5 h-5 text-primary" />
                        <div>
                          <p className="font-semibold text-sm">{h.nombre}</p>
                          <p className="text-[10px] text-muted-foreground">
                            Ingresos: Q. {formatCurrency(parseFloat(h.totalIngresos))} | Egresos: Q. {formatCurrency(parseFloat(h.totalEgresos))}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className={`text-sm font-bold font-mono ${bal >= 0 ? "text-green-600" : "text-red-500"}`}>
                          Q. {formatCurrency(Math.abs(bal))}
                        </span>
                        <button
                          onClick={(e) => { e.stopPropagation(); eliminarHoja(h.id); }}
                          className="text-destructive hover:text-destructive/80 p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card className="p-8 text-center">
              <Wallet className="w-8 h-8 text-muted-foreground/50 mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">
                No hay hojas financieras. Crea una para comenzar a registrar ingresos y egresos.
              </p>
            </Card>
          )}
        </div>
      </DashboardLayout>
    );
  }

  // View: Sheet detail with movements
  return (
    <DashboardLayout>
      <div className="max-w-3xl mx-auto">
        {/* Header with back button */}
        <div className="flex items-center gap-3 mb-4">
          <Button variant="ghost" size="sm" onClick={() => setHojaActiva(null)} className="h-8 w-8 p-0">
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-lg sm:text-xl font-bold text-foreground" style={{ fontFamily: "'Oswald', sans-serif" }}>
              {hoja?.nombre || "Cargando..."}
            </h1>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-3 gap-2 sm:gap-3 mb-4">
          <Card className="p-3 sm:p-4 text-center">
            <TrendingUp className="w-4 h-4 text-green-600 mx-auto mb-1" />
            <p className="text-[10px] text-muted-foreground uppercase font-semibold">Ingresos</p>
            <p className="text-xs sm:text-sm font-bold text-green-600 font-mono">
              Q. {formatCurrency(ingresos)}
            </p>
          </Card>
          <Card className="p-3 sm:p-4 text-center">
            <TrendingDown className="w-4 h-4 text-red-500 mx-auto mb-1" />
            <p className="text-[10px] text-muted-foreground uppercase font-semibold">Egresos</p>
            <p className="text-xs sm:text-sm font-bold text-red-500 font-mono">
              Q. {formatCurrency(egresos)}
            </p>
          </Card>
          <Card className={`p-3 sm:p-4 text-center ${balance >= 0 ? "border-green-200" : "border-red-200"}`}>
            <Wallet className={`w-4 h-4 mx-auto mb-1 ${balance >= 0 ? "text-green-600" : "text-red-500"}`} />
            <p className="text-[10px] text-muted-foreground uppercase font-semibold">Balance</p>
            <p className={`text-xs sm:text-sm font-bold font-mono ${balance >= 0 ? "text-green-600" : "text-red-500"}`}>
              {balance < 0 ? "- " : ""}Q. {formatCurrency(Math.abs(balance))}
            </p>
          </Card>
        </div>

        {/* Add Movement */}
        <Card className="p-4 sm:p-5 mb-4 bg-muted/30">
          <h3 className="text-sm font-bold text-foreground mb-3 uppercase tracking-wide">
            Nuevo Movimiento
          </h3>
          <div className="flex gap-2 mb-3">
            <Button
              variant={tipoNuevo === "ingreso" ? "default" : "outline"}
              size="sm"
              onClick={() => setTipoNuevo("ingreso")}
              className={tipoNuevo === "ingreso" ? "bg-green-600 hover:bg-green-700 text-white" : ""}
            >
              Ingreso
            </Button>
            <Button
              variant={tipoNuevo === "egreso" ? "default" : "outline"}
              size="sm"
              onClick={() => setTipoNuevo("egreso")}
              className={tipoNuevo === "egreso" ? "bg-red-500 hover:bg-red-600 text-white" : ""}
            >
              Egreso
            </Button>
          </div>
          <div className="grid grid-cols-[1fr_100px] sm:grid-cols-[1fr_130px] gap-2 sm:gap-3 mb-3">
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Descripción</Label>
              <Input
                value={descripcion}
                onChange={(e) => setDescripcion(e.target.value)}
                placeholder="Ej. Pago de servicio"
                className="h-9 text-sm"
                onKeyDown={(e) => e.key === "Enter" && agregarMovimiento()}
              />
            </div>
            <div>
              <Label className="text-[10px] font-semibold text-muted-foreground mb-1 block">Monto (Q)</Label>
              <Input
                type="number"
                value={monto}
                onChange={(e) => setMonto(e.target.value)}
                placeholder="0"
                step="0.01"
                className="h-9 text-sm"
                onKeyDown={(e) => e.key === "Enter" && agregarMovimiento()}
              />
            </div>
          </div>
          <Button
            onClick={agregarMovimiento}
            size="sm"
            disabled={saving}
            className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            <Plus className="w-4 h-4 mr-1" />
            {saving ? "Guardando..." : "Agregar"}
          </Button>
        </Card>

        {/* Movements Table */}
        {movimientos.length > 0 ? (
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-foreground text-background">
                    <th className="py-2.5 px-3 text-left text-xs font-semibold">Fecha</th>
                    <th className="py-2.5 px-3 text-left text-xs font-semibold">Descripción</th>
                    <th className="py-2.5 px-3 text-right text-xs font-semibold">Monto</th>
                    <th className="py-2.5 px-3 text-center text-xs font-semibold w-[8%]"></th>
                  </tr>
                </thead>
                <tbody>
                  {movimientos.map((mov: Movimiento) => (
                    <tr key={mov.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                      <td className="py-2.5 px-3 text-xs text-muted-foreground whitespace-nowrap">{new Date(mov.fecha).toLocaleDateString()}</td>
                      <td className="py-2.5 px-3">{mov.descripcion}</td>
                      <td className={`py-2.5 px-3 text-right whitespace-nowrap font-mono text-xs font-semibold ${
                        mov.tipo === "ingreso" ? "text-green-600" : "text-red-500"
                      }`}>
                        {mov.tipo === "ingreso" ? "+" : "-"} Q. {formatCurrency(parseFloat(mov.monto))}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <button
                          onClick={() => eliminarMovimiento(mov.id)}
                          className="text-destructive hover:text-destructive/80 transition-colors p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        ) : (
          <Card className="p-8 text-center">
            <Wallet className="w-8 h-8 text-muted-foreground/50 mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">
              No hay movimientos. Agrega ingresos o egresos para comenzar.
            </p>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}

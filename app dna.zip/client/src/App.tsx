import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import CotizadorSimple from "./pages/CotizadorSimple";
import CotizadorVehiculo from "./pages/CotizadorVehiculo";
import IngresoAutos from "./pages/IngresoAutos";
import HistorialAutos from "./pages/HistorialAutos";
import Historial from "./pages/Historial";
import Finanzas from "./pages/Finanzas";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/cotizador"} component={CotizadorSimple} />
      <Route path={"/cotizador-vehiculo"} component={CotizadorVehiculo} />
      <Route path={"/ingreso-autos"} component={IngresoAutos} />
      <Route path={"/historial-autos"} component={HistorialAutos} />
      <Route path={"/historial"} component={Historial} />
      <Route path={"/finanzas"} component={Finanzas} />
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;

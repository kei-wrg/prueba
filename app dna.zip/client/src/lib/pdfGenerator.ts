import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

interface CotizacionItem {
  cantidad: number;
  concepto: string;
  precioUnitario: string;
  total: string;
}

interface CotizacionData {
  tipo: "simple" | "vehiculo";
  cliente: string;
  fecha: string;
  placa?: string;
  marca?: string;
  modelo?: string;
  anio?: string;
  color?: string;
  motor?: string;
  cilindraje?: string;
  servicio?: string;
  total: string;
  items: CotizacionItem[];
}

function formatCurrency(amount: number): string {
  if (amount % 1 === 0) {
    return new Intl.NumberFormat("en-US", {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  }
  return new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function generarPDFCotizacion(data: CotizacionData): void {
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 15;
  const contentWidth = pageWidth - margin * 2;
  let y = margin;

  // Header - Company name
  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.setTextColor(44, 62, 80);
  doc.text("TALLER DNA", margin, y + 8);

  // Subtitle
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(120, 120, 120);
  doc.text("Mantenimiento, reparación y diagnóstico automotriz", margin, y + 14);
  doc.text("31 AV 10-54 ZONA 7 CARRIL AUXILIAR PERIFERICO TIKAL 1", margin, y + 18);
  doc.text("Teléfono: 3404 - 3879 | Guatemala", margin, y + 22);

  // Title right side
  doc.setFont("helvetica", "bold");
  doc.setFontSize(22);
  doc.setTextColor(200, 200, 200);
  doc.text("COTIZACIÓN", pageWidth - margin, y + 10, { align: "right" });

  // Reference number
  doc.setFontSize(9);
  doc.setTextColor(22, 160, 133);
  const ref = `#DNA-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 999) + 1).padStart(3, "0")}`;
  doc.text(`REF: ${ref}`, pageWidth - margin, y + 16, { align: "right" });

  y += 30;

  // Separator line
  doc.setDrawColor(22, 160, 133);
  doc.setLineWidth(0.5);
  doc.line(margin, y, pageWidth - margin, y);
  y += 8;

  // Client info section
  doc.setFillColor(248, 249, 250);
  doc.rect(margin, y, contentWidth, data.tipo === "vehiculo" ? 32 : 16, "F");

  // Left border accent
  doc.setFillColor(22, 160, 133);
  doc.rect(margin, y, 1.5, data.tipo === "vehiculo" ? 32 : 16, "F");

  doc.setFont("helvetica", "normal");
  doc.setFontSize(7);
  doc.setTextColor(150, 150, 150);
  doc.text("PREPARADO PARA:", margin + 5, y + 5);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.setTextColor(44, 62, 80);
  doc.text(data.cliente, margin + 5, y + 11);

  // Date on right
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7);
  doc.setTextColor(150, 150, 150);
  doc.text("FECHA:", pageWidth - margin - 30, y + 5);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(44, 62, 80);
  doc.text(data.fecha, pageWidth - margin - 30, y + 11);

  // Vehicle data if applicable
  if (data.tipo === "vehiculo") {
    y += 15;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7);
    doc.setTextColor(100, 100, 100);

    const vehicleInfo = [];
    if (data.marca) vehicleInfo.push(`Marca: ${data.marca}`);
    if (data.modelo) vehicleInfo.push(`Modelo: ${data.modelo}`);
    if (data.anio) vehicleInfo.push(`Año: ${data.anio}`);
    if (data.color) vehicleInfo.push(`Color: ${data.color}`);
    if (data.placa) vehicleInfo.push(`Placa: ${data.placa}`);
    if (data.motor) vehicleInfo.push(`Motor: ${data.motor}`);
    if (data.cilindraje) vehicleInfo.push(`Cilindraje: ${data.cilindraje}`);

    doc.setFontSize(8);
    const line1 = vehicleInfo.slice(0, 4).join("  |  ");
    const line2 = vehicleInfo.slice(4).join("  |  ");
    doc.text(line1, margin + 5, y + 2);
    if (line2) {
      doc.text(line2, margin + 5, y + 7);
    }

    if (data.servicio) {
      doc.setFont("helvetica", "italic");
      doc.setFontSize(8);
      doc.setTextColor(22, 160, 133);
      doc.text(`Servicio: ${data.servicio}`, margin + 5, y + (line2 ? 12 : 7));
    }

    y += (data.tipo === "vehiculo" ? 20 : 5);
  } else {
    y += 20;
  }

  y += 5;

  // Table
  const tableData = data.items.map(item => [
    item.cantidad.toString(),
    item.concepto,
    `Q. ${formatCurrency(parseFloat(item.precioUnitario))}`,
    `Q. ${formatCurrency(parseFloat(item.total))}`,
  ]);

  autoTable(doc, {
    startY: y,
    head: [["Cant.", "Descripción del Servicio", "Precio Unit.", "Importe"]],
    body: tableData,
    margin: { left: margin, right: margin },
    headStyles: {
      fillColor: [44, 62, 80],
      textColor: [255, 255, 255],
      fontSize: 8,
      fontStyle: "bold",
      cellPadding: 4,
    },
    bodyStyles: {
      fontSize: 8,
      cellPadding: 3.5,
      textColor: [50, 50, 50],
    },
    alternateRowStyles: {
      fillColor: [250, 250, 250],
    },
    columnStyles: {
      0: { halign: "center", cellWidth: 15 },
      1: { cellWidth: "auto" },
      2: { halign: "right", cellWidth: 30 },
      3: { halign: "right", cellWidth: 30, fontStyle: "bold" },
    },
    theme: "plain",
    tableLineColor: [230, 230, 230],
    tableLineWidth: 0.1,
    didDrawCell: (hookData) => {
      if (hookData.section === "body") {
        doc.setDrawColor(240, 240, 240);
        doc.setLineWidth(0.1);
        doc.line(
          hookData.cell.x,
          hookData.cell.y + hookData.cell.height,
          hookData.cell.x + hookData.cell.width,
          hookData.cell.y + hookData.cell.height
        );
      }
    },
  });

  // Get final Y after table
  const finalY = (doc as any).lastAutoTable.finalY + 8;

  // Total section
  const totalBoxWidth = 80;
  const totalBoxX = pageWidth - margin - totalBoxWidth;

  doc.setDrawColor(22, 160, 133);
  doc.setLineWidth(0.8);
  doc.line(totalBoxX, finalY, pageWidth - margin, finalY);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(44, 62, 80);
  doc.text("TOTAL:", totalBoxX + 5, finalY + 7);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.text(`Q. ${formatCurrency(parseFloat(data.total))}`, pageWidth - margin, finalY + 7, { align: "right" });

  // Footer
  const footerY = finalY + 25;
  doc.setDrawColor(230, 230, 230);
  doc.setLineWidth(0.2);
  doc.line(margin, footerY, pageWidth - margin, footerY);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(180, 180, 180);
  doc.text("Gracias por confiar en Taller DNA", pageWidth / 2, footerY + 5, { align: "center" });

  // Generate filename
  let filename: string;
  if (data.tipo === "simple") {
    filename = `Cotizacion_${data.cliente.trim().replace(/\s+/g, "_")}`;
  } else {
    const autoName = [data.marca, data.modelo].filter(Boolean).join("_");
    filename = `Cotizacion_${autoName || data.cliente.trim().replace(/\s+/g, "_")}`;
  }

  doc.save(`${filename}.pdf`);
}

// Convenience wrappers
export interface SimpleQuoteData {
  cliente: string;
  fecha: string;
  items: { cantidad: number; concepto: string; precio: number; total: number }[];
  total: number;
}

export interface VehicleQuoteData {
  cliente: string;
  fecha: string;
  placa: string;
  marca: string;
  modelo: string;
  anio: string;
  color: string;
  motor: string;
  cilindraje: string;
  items: { cantidad: number; concepto: string; precio: number; total: number }[];
  total: number;
}

export function generateSimplePDF(data: SimpleQuoteData): void {
  generarPDFCotizacion({
    tipo: "simple",
    cliente: data.cliente,
    fecha: data.fecha,
    total: data.total.toString(),
    items: data.items.map(i => ({
      cantidad: i.cantidad,
      concepto: i.concepto,
      precioUnitario: i.precio.toString(),
      total: i.total.toString(),
    })),
  });
}

export function generateVehiclePDF(data: VehicleQuoteData): void {
  generarPDFCotizacion({
    tipo: "vehiculo",
    cliente: data.cliente,
    fecha: data.fecha,
    placa: data.placa,
    marca: data.marca,
    modelo: data.modelo,
    anio: data.anio,
    color: data.color,
    motor: data.motor,
    cilindraje: data.cilindraje,
    total: data.total.toString(),
    items: data.items.map(i => ({
      cantidad: i.cantidad,
      concepto: i.concepto,
      precioUnitario: i.precio.toString(),
      total: i.total.toString(),
    })),
  });
}

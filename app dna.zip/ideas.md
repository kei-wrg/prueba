# Cotizador DNA - Brainstorming de Diseño

## Tres Enfoques Estilísticos

### 1. Industrial Refinado
**Intro**: Estética de taller de alta gama con texturas metálicas, tipografía bold y colores oscuros con acentos turquesa. Transmite confianza y profesionalismo mecánico.
**Probabilidad**: 0.07

### 2. Minimalismo Corporativo
**Intro**: Diseño ultra-limpio con mucho espacio en blanco, tipografía sans-serif delgada y un solo color de acento. Enfocado en la funcionalidad pura.
**Probabilidad**: 0.04

### 3. Neo-Brutalismo Automotriz
**Intro**: Bordes marcados, sombras duras, tipografía condensada y colores de alto contraste. Evoca la fuerza y precisión de la mecánica.
**Probabilidad**: 0.03

---

## Enfoque Seleccionado: Industrial Refinado

### Design Movement
Inspirado en el **Industrial Design** moderno — la estética de herramientas de precisión, acero pulido y talleres premium. Combina la robustez del mundo automotriz con la elegancia del diseño contemporáneo.

### Core Principles
1. **Solidez Visual**: Elementos con peso, bordes definidos y presencia fuerte
2. **Contraste Funcional**: Jerarquía clara entre información primaria y secundaria
3. **Materialidad**: Sensación de superficies reales (metal, papel, carbono)
4. **Precisión**: Alineación perfecta, espaciado matemático, nada fuera de lugar

### Color Philosophy
- **Base**: Gris carbón profundo (`#1a1a2e`) — evoca el acero y la seriedad
- **Superficie**: Blanco cálido (`#fafafa`) — el papel de la cotización
- **Acento Principal**: Turquesa metálico (`#16a085`) — el color del logo DNA, transmite tecnología y confianza
- **Acento Secundario**: Ámbar (`#f39c12`) — alerta, precios, llamadas a la acción
- **Texto**: Gris oscuro (`#2d3436`) sobre superficies claras

### Layout Paradigm
Diseño de **dos pantallas** (formulario → documento):
- Pantalla 1: Formulario de ingreso con layout asimétrico (sidebar de info + área principal de captura)
- Pantalla 2: Vista previa del documento tipo "hoja de papel" centrada sobre fondo oscuro

### Signature Elements
1. **Línea turquesa lateral** en tarjetas y secciones (evoca una marca de calidad)
2. **Tipografía condensada en mayúsculas** para encabezados (estilo industrial)
3. **Sombras sutiles con profundidad** en el documento final (efecto de papel elevado)

### Interaction Philosophy
Interacciones directas y satisfactorias: botones con feedback táctil (scale en click), transiciones rápidas (150-200ms), sin animaciones innecesarias. Todo debe sentirse como operar una herramienta de precisión.

### Animation
- Transiciones de entrada: `opacity 0→1` + `translateY(8px→0)` en 200ms con ease-out
- Botones: `scale(0.97)` en `:active` con 120ms
- Cambio de pantalla: fade cruzado de 250ms
- Sin animaciones decorativas — solo funcionales

### Typography System
- **Display/Headers**: `Oswald` (condensada, bold) — industrial y memorable
- **Body/Data**: `Inter` weight 400-600 — legibilidad perfecta para números y texto
- **Monospace (precios)**: `JetBrains Mono` — alineación perfecta de cifras

### Brand Essence
**Posicionamiento**: Sistema de cotización profesional para talleres automotrices que necesitan generar documentos impecables en segundos.
**Personalidad**: Preciso, confiable, profesional.

### Brand Voice
- Headlines: directos, en mayúsculas, sin adornos ("NUEVA COTIZACIÓN", "DETALLE DEL SERVICIO")
- CTAs: verbos de acción claros ("Agregar Concepto", "Generar Documento")
- Ejemplo 1: "COTIZACIÓN DE SERVICIOS — TALLER DNA"
- Ejemplo 2: "Documento listo. Descarga tu PDF."

### Wordmark & Logo
Logo existente: engranajes y llave mecánica en metal con texto "MECHANICS DNA". Se usará tal cual, integrado como imagen PNG optimizada.

### Signature Brand Color
**Turquesa Metálico** (`#16a085`) — el color que identifica a Taller DNA, presente en bordes, acentos y elementos interactivos clave.

CREATE TABLE `cotizacion_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cotizacionId` int NOT NULL,
	`cantidad` int NOT NULL DEFAULT 1,
	`concepto` text NOT NULL,
	`precioUnitario` decimal(12,2) NOT NULL,
	`total` decimal(12,2) NOT NULL,
	CONSTRAINT `cotizacion_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cotizaciones` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tipo` enum('simple','vehiculo') NOT NULL DEFAULT 'simple',
	`cliente` varchar(255) NOT NULL,
	`fecha` date NOT NULL,
	`placa` varchar(20),
	`marca` varchar(100),
	`modelo` varchar(100),
	`anio` varchar(10),
	`color` varchar(50),
	`motor` varchar(100),
	`cilindraje` varchar(50),
	`servicio` text,
	`total` decimal(12,2) NOT NULL DEFAULT '0',
	`notas` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cotizaciones_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `hojas_financieras` (
	`id` int AUTO_INCREMENT NOT NULL,
	`nombre` varchar(100) NOT NULL,
	`mes` int NOT NULL,
	`anio` int NOT NULL,
	`totalIngresos` decimal(12,2) NOT NULL DEFAULT '0',
	`totalEgresos` decimal(12,2) NOT NULL DEFAULT '0',
	`balance` decimal(12,2) NOT NULL DEFAULT '0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `hojas_financieras_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ingresos_autos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cliente` varchar(255) NOT NULL,
	`telefono` varchar(50),
	`placa` varchar(20) NOT NULL,
	`marca` varchar(100) NOT NULL,
	`modelo` varchar(100) NOT NULL,
	`anio` varchar(10),
	`color` varchar(50),
	`motor` varchar(100),
	`cilindraje` varchar(50),
	`kilometraje` varchar(50),
	`servicioRequerido` text NOT NULL,
	`diagnostico` text,
	`estado` enum('pendiente','en_proceso','completado','entregado') NOT NULL DEFAULT 'pendiente',
	`fechaIngreso` date NOT NULL,
	`fechaEntrega` date,
	`notas` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ingresos_autos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `movimientos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`hojaId` int NOT NULL,
	`tipo` enum('ingreso','egreso') NOT NULL,
	`descripcion` text NOT NULL,
	`monto` decimal(12,2) NOT NULL,
	`fecha` date NOT NULL,
	`categoria` varchar(100),
	`notas` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `movimientos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);

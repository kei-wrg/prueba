import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, date } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Cotizaciones (quotes) - both simple and with vehicle data
 */
export const cotizaciones = mysqlTable("cotizaciones", {
  id: int("id").autoincrement().primaryKey(),
  tipo: mysqlEnum("tipo", ["simple", "vehiculo"]).notNull().default("simple"),
  cliente: varchar("cliente", { length: 255 }).notNull(),
  fecha: date("fecha").notNull(),
  placa: varchar("placa", { length: 20 }),
  marca: varchar("marca", { length: 100 }),
  modelo: varchar("modelo", { length: 100 }),
  anio: varchar("anio", { length: 10 }),
  color: varchar("color", { length: 50 }),
  motor: varchar("motor", { length: 100 }),
  cilindraje: varchar("cilindraje", { length: 50 }),
  servicio: text("servicio"),
  total: decimal("total", { precision: 12, scale: 2 }).notNull().default("0"),
  notas: text("notas"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Cotizacion = typeof cotizaciones.$inferSelect;
export type InsertCotizacion = typeof cotizaciones.$inferInsert;

/**
 * Items/conceptos de cada cotizacion
 */
export const cotizacionItems = mysqlTable("cotizacion_items", {
  id: int("id").autoincrement().primaryKey(),
  cotizacionId: int("cotizacionId").notNull(),
  cantidad: int("cantidad").notNull().default(1),
  concepto: text("concepto").notNull(),
  precioUnitario: decimal("precioUnitario", { precision: 12, scale: 2 }).notNull(),
  total: decimal("total", { precision: 12, scale: 2 }).notNull(),
});

export type CotizacionItem = typeof cotizacionItems.$inferSelect;
export type InsertCotizacionItem = typeof cotizacionItems.$inferInsert;

/**
 * Ingreso de autos al taller
 */
export const ingresosAutos = mysqlTable("ingresos_autos", {
  id: int("id").autoincrement().primaryKey(),
  cliente: varchar("cliente", { length: 255 }).notNull(),
  telefono: varchar("telefono", { length: 50 }),
  placa: varchar("placa", { length: 20 }).notNull(),
  marca: varchar("marca", { length: 100 }).notNull(),
  modelo: varchar("modelo", { length: 100 }).notNull(),
  anio: varchar("anio", { length: 10 }),
  color: varchar("color", { length: 50 }),
  motor: varchar("motor", { length: 100 }),
  cilindraje: varchar("cilindraje", { length: 50 }),
  kilometraje: varchar("kilometraje", { length: 50 }),
  servicioRequerido: text("servicioRequerido").notNull(),
  diagnostico: text("diagnostico"),
  estado: mysqlEnum("estado", ["pendiente", "en_proceso", "completado", "entregado"]).notNull().default("pendiente"),
  fechaIngreso: date("fechaIngreso").notNull(),
  fechaEntrega: date("fechaEntrega"),
  notas: text("notas"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type IngresoAuto = typeof ingresosAutos.$inferSelect;
export type InsertIngresoAuto = typeof ingresosAutos.$inferInsert;

/**
 * Control financiero - hojas mensuales
 */
export const hojasFinancieras = mysqlTable("hojas_financieras", {
  id: int("id").autoincrement().primaryKey(),
  nombre: varchar("nombre", { length: 100 }).notNull(),
  mes: int("mes").notNull(),
  anio: int("anio").notNull(),
  totalIngresos: decimal("totalIngresos", { precision: 12, scale: 2 }).notNull().default("0"),
  totalEgresos: decimal("totalEgresos", { precision: 12, scale: 2 }).notNull().default("0"),
  balance: decimal("balance", { precision: 12, scale: 2 }).notNull().default("0"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type HojaFinanciera = typeof hojasFinancieras.$inferSelect;
export type InsertHojaFinanciera = typeof hojasFinancieras.$inferInsert;

/**
 * Movimientos financieros (debitos y creditos)
 */
export const movimientos = mysqlTable("movimientos", {
  id: int("id").autoincrement().primaryKey(),
  hojaId: int("hojaId").notNull(),
  tipo: mysqlEnum("tipo", ["ingreso", "egreso"]).notNull(),
  descripcion: text("descripcion").notNull(),
  monto: decimal("monto", { precision: 12, scale: 2 }).notNull(),
  fecha: date("fecha").notNull(),
  categoria: varchar("categoria", { length: 100 }),
  notas: text("notas"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Movimiento = typeof movimientos.$inferSelect;
export type InsertMovimiento = typeof movimientos.$inferInsert;
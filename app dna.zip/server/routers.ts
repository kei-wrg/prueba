import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

const cotizacionItemSchema = z.object({
  cantidad: z.number().min(1),
  concepto: z.string().min(1),
  precioUnitario: z.string(),
  total: z.string(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  cotizaciones: router({
    list: protectedProcedure.query(async () => {
      return db.getCotizaciones();
    }),
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getCotizacionById(input.id);
      }),
    create: protectedProcedure
      .input(z.object({
        tipo: z.enum(["simple", "vehiculo"]),
        cliente: z.string().min(1),
        fecha: z.string(),
        placa: z.string().optional(),
        marca: z.string().optional(),
        modelo: z.string().optional(),
        anio: z.string().optional(),
        color: z.string().optional(),
        motor: z.string().optional(),
        cilindraje: z.string().optional(),
        servicio: z.string().optional(),
        total: z.string(),
        notas: z.string().optional(),
        items: z.array(cotizacionItemSchema),
      }))
      .mutation(async ({ input }) => {
        const { items, ...data } = input;
        const id = await db.createCotizacion(data as any, items);
        return { id };
      }),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        tipo: z.enum(["simple", "vehiculo"]).optional(),
        cliente: z.string().optional(),
        fecha: z.string().optional(),
        placa: z.string().optional(),
        marca: z.string().optional(),
        modelo: z.string().optional(),
        anio: z.string().optional(),
        color: z.string().optional(),
        motor: z.string().optional(),
        cilindraje: z.string().optional(),
        servicio: z.string().optional(),
        total: z.string().optional(),
        notas: z.string().optional(),
        items: z.array(cotizacionItemSchema).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, items, ...data } = input;
        await db.updateCotizacion(id, data as any, items);
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteCotizacion(input.id);
        return { success: true };
      }),
  }),

  autos: router({
    list: protectedProcedure.query(async () => {
      return db.getIngresosAutos();
    }),
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getIngresoAutoById(input.id);
      }),
    create: protectedProcedure
      .input(z.object({
        cliente: z.string().min(1),
        telefono: z.string().optional(),
        placa: z.string().min(1),
        marca: z.string().min(1),
        modelo: z.string().min(1),
        anio: z.string().optional(),
        color: z.string().optional(),
        motor: z.string().optional(),
        cilindraje: z.string().optional(),
        kilometraje: z.string().optional(),
        servicioRequerido: z.string().min(1),
        diagnostico: z.string().optional(),
        estado: z.enum(["pendiente", "en_proceso", "completado", "entregado"]).optional(),
        fechaIngreso: z.string(),
        fechaEntrega: z.string().optional(),
        notas: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const id = await db.createIngresoAuto(input as any);
        return { id };
      }),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        cliente: z.string().optional(),
        telefono: z.string().optional(),
        placa: z.string().optional(),
        marca: z.string().optional(),
        modelo: z.string().optional(),
        anio: z.string().optional(),
        color: z.string().optional(),
        motor: z.string().optional(),
        cilindraje: z.string().optional(),
        kilometraje: z.string().optional(),
        servicioRequerido: z.string().optional(),
        diagnostico: z.string().optional(),
        estado: z.enum(["pendiente", "en_proceso", "completado", "entregado"]).optional(),
        fechaIngreso: z.string().optional(),
        fechaEntrega: z.string().optional(),
        notas: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateIngresoAuto(id, data as any);
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteIngresoAuto(input.id);
        return { success: true };
      }),
  }),

  finanzas: router({
    listHojas: protectedProcedure.query(async () => {
      return db.getHojasFinancieras();
    }),
    getHoja: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getHojaFinancieraById(input.id);
      }),
    createHoja: protectedProcedure
      .input(z.object({
        nombre: z.string().min(1),
        mes: z.number().min(1).max(12),
        anio: z.number().min(2020).max(2100),
      }))
      .mutation(async ({ input }) => {
        const id = await db.createHojaFinanciera({
          ...input,
          totalIngresos: "0",
          totalEgresos: "0",
          balance: "0",
        });
        return { id };
      }),
    deleteHoja: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteHojaFinanciera(input.id);
        return { success: true };
      }),
    createMovimiento: protectedProcedure
      .input(z.object({
        hojaId: z.number(),
        tipo: z.enum(["ingreso", "egreso"]),
        descripcion: z.string().min(1),
        monto: z.string(),
        fecha: z.string(),
        categoria: z.string().optional(),
        notas: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const id = await db.createMovimiento(input as any);
        return { id };
      }),
    updateMovimiento: protectedProcedure
      .input(z.object({
        id: z.number(),
        tipo: z.enum(["ingreso", "egreso"]).optional(),
        descripcion: z.string().optional(),
        monto: z.string().optional(),
        fecha: z.string().optional(),
        categoria: z.string().optional(),
        notas: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateMovimiento(id, data as any);
        return { success: true };
      }),
    deleteMovimiento: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteMovimiento(input.id);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;

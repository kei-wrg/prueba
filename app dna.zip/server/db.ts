import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, cotizaciones, cotizacionItems, ingresosAutos, hojasFinancieras, movimientos } from "../drizzle/schema";
import type { InsertCotizacion, InsertCotizacionItem, InsertIngresoAuto, InsertHojaFinanciera, InsertMovimiento } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ COTIZACIONES ============

export async function createCotizacion(data: InsertCotizacion, items: Omit<InsertCotizacionItem, "cotizacionId">[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [result] = await db.insert(cotizaciones).values(data).$returningId();
  const cotizacionId = result.id;

  if (items.length > 0) {
    await db.insert(cotizacionItems).values(
      items.map(item => ({ ...item, cotizacionId }))
    );
  }

  return cotizacionId;
}

export async function getCotizaciones() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(cotizaciones).orderBy(desc(cotizaciones.createdAt));
}

export async function getCotizacionById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [cotizacion] = await db.select().from(cotizaciones).where(eq(cotizaciones.id, id)).limit(1);
  if (!cotizacion) return null;

  const items = await db.select().from(cotizacionItems).where(eq(cotizacionItems.cotizacionId, id));
  return { ...cotizacion, items };
}

export async function updateCotizacion(id: number, data: Partial<InsertCotizacion>, items?: Omit<InsertCotizacionItem, "cotizacionId">[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(cotizaciones).set(data).where(eq(cotizaciones.id, id));

  if (items) {
    await db.delete(cotizacionItems).where(eq(cotizacionItems.cotizacionId, id));
    if (items.length > 0) {
      await db.insert(cotizacionItems).values(
        items.map(item => ({ ...item, cotizacionId: id }))
      );
    }
  }
}

export async function deleteCotizacion(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(cotizacionItems).where(eq(cotizacionItems.cotizacionId, id));
  await db.delete(cotizaciones).where(eq(cotizaciones.id, id));
}

// ============ INGRESO DE AUTOS ============

export async function createIngresoAuto(data: InsertIngresoAuto) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [result] = await db.insert(ingresosAutos).values(data).$returningId();
  return result.id;
}

export async function getIngresosAutos() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(ingresosAutos).orderBy(desc(ingresosAutos.createdAt));
}

export async function getIngresoAutoById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [result] = await db.select().from(ingresosAutos).where(eq(ingresosAutos.id, id)).limit(1);
  return result || null;
}

export async function updateIngresoAuto(id: number, data: Partial<InsertIngresoAuto>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(ingresosAutos).set(data).where(eq(ingresosAutos.id, id));
}

export async function deleteIngresoAuto(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(ingresosAutos).where(eq(ingresosAutos.id, id));
}

// ============ HOJAS FINANCIERAS ============

export async function createHojaFinanciera(data: InsertHojaFinanciera) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [result] = await db.insert(hojasFinancieras).values(data).$returningId();
  return result.id;
}

export async function getHojasFinancieras() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(hojasFinancieras).orderBy(desc(hojasFinancieras.anio), desc(hojasFinancieras.mes));
}

export async function getHojaFinancieraById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [hoja] = await db.select().from(hojasFinancieras).where(eq(hojasFinancieras.id, id)).limit(1);
  if (!hoja) return null;

  const movs = await db.select().from(movimientos).where(eq(movimientos.hojaId, id)).orderBy(desc(movimientos.fecha));
  return { ...hoja, movimientos: movs };
}

export async function deleteHojaFinanciera(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(movimientos).where(eq(movimientos.hojaId, id));
  await db.delete(hojasFinancieras).where(eq(hojasFinancieras.id, id));
}

// ============ MOVIMIENTOS ============

export async function createMovimiento(data: InsertMovimiento) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [result] = await db.insert(movimientos).values(data).$returningId();
  await recalcularHoja(data.hojaId);
  return result.id;
}

export async function updateMovimiento(id: number, data: Partial<InsertMovimiento>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [mov] = await db.select().from(movimientos).where(eq(movimientos.id, id)).limit(1);
  if (!mov) throw new Error("Movimiento not found");

  await db.update(movimientos).set(data).where(eq(movimientos.id, id));
  await recalcularHoja(mov.hojaId);
}

export async function deleteMovimiento(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [mov] = await db.select().from(movimientos).where(eq(movimientos.id, id)).limit(1);
  if (!mov) throw new Error("Movimiento not found");

  await db.delete(movimientos).where(eq(movimientos.id, id));
  await recalcularHoja(mov.hojaId);
}

async function recalcularHoja(hojaId: number) {
  const db = await getDb();
  if (!db) return;

  const movs = await db.select().from(movimientos).where(eq(movimientos.hojaId, hojaId));
  
  let totalIngresos = 0;
  let totalEgresos = 0;

  for (const mov of movs) {
    const monto = parseFloat(mov.monto);
    if (mov.tipo === "ingreso") {
      totalIngresos += monto;
    } else {
      totalEgresos += monto;
    }
  }

  const balance = totalIngresos - totalEgresos;

  await db.update(hojasFinancieras).set({
    totalIngresos: totalIngresos.toFixed(2),
    totalEgresos: totalEgresos.toFixed(2),
    balance: balance.toFixed(2),
  }).where(eq(hojasFinancieras.id, hojaId));
}
